You may not reproduce this code to create your own apps.
